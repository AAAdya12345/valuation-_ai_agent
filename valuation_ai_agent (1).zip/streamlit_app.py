import streamlit as st
from valuation_engine import parse_excel, run_dcf
from report_generator import generate_ai_narrative, create_pdf

st.set_page_config(page_title="Valuation AI Agent", layout="centered")

st.title("📊 Valuation AI Agent for CA Firms")

uploaded_file = st.file_uploader("Upload financial Excel file", type=["xls", "xlsx"])

if uploaded_file:
    st.success("✅ File uploaded successfully")
    sheets = parse_excel(uploaded_file)
    sheet_names = list(sheets.keys())
    selected_sheet = st.selectbox("Select sheet with financials", sheet_names)
    df = sheets[selected_sheet]
    st.subheader("🔍 Preview Financial Data")
    st.dataframe(df.head())

    if st.button("Run Valuation"):
        try:
            summary = run_dcf(df)
            st.subheader("📈 Valuation Summary")
            st.json(summary)
            narrative = generate_ai_narrative(summary)
            st.subheader("📝 Draft Report")
            st.write(narrative)
            pdf = create_pdf(summary, narrative)
            st.download_button("📥 Download Report as PDF", data=pdf, file_name="valuation_report.pdf")
        except Exception as e:
            st.error(f"Error processing file: {e}")