import pandas as pd

def parse_excel(file):
    df = pd.read_excel(file, sheet_name=None)
    return df

def run_dcf(financials, discount_rate=0.12, terminal_growth=0.04):
    revenues = financials['Revenue'].values
    current_revenue = revenues[-1]
    future_revenue = [current_revenue * (1 + 0.1) ** i for i in range(1, 6)]
    free_cash_flows = [rev * 0.2 for rev in future_revenue]

    npv = sum(fcf / ((1 + discount_rate) ** i) for i, fcf in enumerate(free_cash_flows, 1))
    terminal_value = (free_cash_flows[-1] * (1 + terminal_growth)) / (discount_rate - terminal_growth)
    terminal_npv = terminal_value / ((1 + discount_rate) ** 5)

    enterprise_value = npv + terminal_npv

    return {
        "Forecast Revenues": future_revenue,
        "Free Cash Flows": free_cash_flows,
        "NPV": npv,
        "Terminal Value": terminal_value,
        "Enterprise Value": enterprise_value
    }