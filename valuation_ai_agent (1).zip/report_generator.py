from fpdf import FPDF

class PDF(FPDF):
    def header(self):
        self.set_font("DejaVu", size=14)
        self.cell(0, 10, "Valuation Report", ln=True, align="C")

    def chapter(self, title, text):
        self.set_font("DejaVu", size=12)
        self.ln(10)
        self.cell(0, 10, title, ln=True)
        self.multi_cell(0, 10, text)

def generate_ai_narrative(summary):
    return f"""Based on a discounted cash flow analysis, the estimated enterprise value is ₹{summary['Enterprise Value']:,.2f}.
The forecast assumes a WACC of 12% and a terminal growth rate of 4%. These projections are based on the last financial year data provided.
All assumptions and financial forecasts should be reviewed by a qualified professional."""


def create_pdf(summary, narrative):
    pdf = PDF()
    pdf.add_page()
    pdf.add_font("DejaVu", "", "fonts/DejaVuSans.ttf", uni=True)
    pdf.set_font("DejaVu", size=12)
    pdf.chapter("Valuation Summary", f"""
NPV: ₹{summary['NPV']:,.2f}
Terminal Value: ₹{summary['Terminal Value']:,.2f}
Enterprise Value: ₹{summary['Enterprise Value']:,.2f}
""")
    pdf.chapter("Draft Narrative", narrative)
    return pdf.output(dest='S').encode('latin-1')